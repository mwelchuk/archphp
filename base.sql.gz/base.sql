-- MySQL dump 9.11
--
-- Host: localhost    Database: luac
-- ------------------------------------------------------
-- Server version	4.0.24_Debian-10sarge2-log

--
-- Table structure for table `class`
--

CREATE TABLE class (
  c_uid int(10) unsigned NOT NULL auto_increment,
  c_name text NOT NULL,
  c_desc text,
  UNIQUE KEY c_uid (c_uid)
) TYPE=MyISAM COMMENT='Table to hold Bow Classes';

--
-- Dumping data for table `class`
--

INSERT INTO class VALUES (1,'Recurve','Standard Recurve Bow...');
INSERT INTO class VALUES (2,'Compound','The one with cams on it!');
INSERT INTO class VALUES (3,'Bare Bow','Standard Bow without a sight.');
INSERT INTO class VALUES (4,'Longbow','Special Class for traditional Longbows - Is this required?');

--
-- Table structure for table `distance`
--

CREATE TABLE distance (
  d_uid int(11) NOT NULL auto_increment,
  distance int(11) NOT NULL default '0',
  unit tinytext NOT NULL,
  UNIQUE KEY d_uid (d_uid)
) TYPE=MyISAM COMMENT='Table to hold all possible different distances';

--
-- Dumping data for table `distance`
--

INSERT INTO distance VALUES (1,20,'i');
INSERT INTO distance VALUES (2,30,'i');
INSERT INTO distance VALUES (3,40,'i');
INSERT INTO distance VALUES (4,20,'m');
INSERT INTO distance VALUES (5,30,'m');
INSERT INTO distance VALUES (6,40,'m');
INSERT INTO distance VALUES (7,60,'i');
INSERT INTO distance VALUES (8,80,'i');
INSERT INTO distance VALUES (9,100,'i');
INSERT INTO distance VALUES (10,90,'m');
INSERT INTO distance VALUES (11,18,'m');
INSERT INTO distance VALUES (12,25,'m');
INSERT INTO distance VALUES (13,50,'i');
INSERT INTO distance VALUES (14,15,'i');
INSERT INTO distance VALUES (15,25,'i');

--
-- Table structure for table `documentation`
--

CREATE TABLE documentation (
  d_uid int(10) unsigned NOT NULL auto_increment,
  date date NOT NULL default '0000-00-00',
  title tinytext NOT NULL,
  description text,
  content mediumtext,
  UNIQUE KEY d_uid (d_uid)
) TYPE=MyISAM COMMENT='holds editable club documentation';

--
-- Table structure for table `end`
--

CREATE TABLE end (
  e_uid int(11) NOT NULL auto_increment,
  session int(11) NOT NULL default '0',
  distance int(11) NOT NULL default '0',
  end int(11) NOT NULL default '0',
  value1 tinytext NOT NULL,
  value2 tinytext NOT NULL,
  value3 tinytext NOT NULL,
  value4 tinytext NOT NULL,
  value5 tinytext NOT NULL,
  value6 tinytext NOT NULL,
  UNIQUE KEY e_uid (e_uid)
) TYPE=MyISAM COMMENT='Table to hold all ends';

--
-- Table structure for table `equipment`
--

CREATE TABLE equipment (
  eq_uid int(10) NOT NULL auto_increment,
  user int(10) NOT NULL default '0',
  e_name text NOT NULL,
  class text NOT NULL,
  bow text NOT NULL,
  arrows text NOT NULL,
  sight text,
  stabilisation text,
  extras text,
  e_desc text,
  UNIQUE KEY eq_uid (eq_uid)
) TYPE=MyISAM COMMENT='Equipment List';

--
-- Table structure for table `exec`
--

CREATE TABLE exec (
  pos_uid int(10) unsigned NOT NULL auto_increment,
  position tinytext,
  user int(10) unsigned default NULL,
  duties text,
  picture mediumblob,
  UNIQUE KEY pos_uid (pos_uid)
) TYPE=MyISAM COMMENT='Holds extra information on exec positions';

--
-- Table structure for table `face`
--

CREATE TABLE face (
  f_uid int(11) NOT NULL auto_increment,
  f_name text NOT NULL,
  size int(11) NOT NULL default '0',
  number int(11) NOT NULL default '0',
  UNIQUE KEY f_uid (f_uid)
) TYPE=MyISAM COMMENT='table of face types';

--
-- Dumping data for table `face`
--

INSERT INTO face VALUES (1,'Large (122cm)',122,1);
INSERT INTO face VALUES (2,'Medium (60cm)',60,1);
INSERT INTO face VALUES (3,'Small (40cm)',40,1);
INSERT INTO face VALUES (4,'Small Tripple Spot Vertical (40cm - only to inner blue)',40,3);
INSERT INTO face VALUES (5,'Big (80cm)',80,1);
INSERT INTO face VALUES (6,'Small Tripple Spot Trangular (40cm - only to inner blue)',40,3);
INSERT INTO face VALUES (7,'Large Tripple Spot Vertical (60cm - only to inner blue)',60,3);
INSERT INTO face VALUES (8,'Large Tripple Spot Trangular (60cm - only to inner blue)',60,3);

--
-- Table structure for table `news`
--

CREATE TABLE news (
  n_uid int(11) NOT NULL auto_increment,
  date date NOT NULL default '0000-00-00',
  title tinytext NOT NULL,
  content mediumtext NOT NULL,
  UNIQUE KEY n_uid (n_uid)
) TYPE=MyISAM COMMENT='News to show on front page';

--
-- Dumping data for table `news`
--

INSERT INTO news VALUES (1,'0000-00-00','The News Section','<p>All your clubs news.</p>');

--
-- Table structure for table `priv_level`
--

CREATE TABLE priv_level (
  p_uid tinyint(3) unsigned NOT NULL auto_increment,
  name tinytext NOT NULL,
  UNIQUE KEY p_uid (p_uid)
) TYPE=MyISAM COMMENT='List of Available Privilege Levels';

--
-- Dumping data for table `priv_level`
--

INSERT INTO priv_level VALUES (2,'edit_users');
INSERT INTO priv_level VALUES (1,'view_users');
INSERT INTO priv_level VALUES (4,'edit_classes');
INSERT INTO priv_level VALUES (8,'edit_rounds');
INSERT INTO priv_level VALUES (128,'edit_privileges');
INSERT INTO priv_level VALUES (16,'edit_shoots');
INSERT INTO priv_level VALUES (32,'edit_news');
INSERT INTO priv_level VALUES (64,'edit_docs');

--
-- Table structure for table `requests`
--

CREATE TABLE requests (
  hash text NOT NULL,
  email tinytext NOT NULL,
  priv tinyint(3) unsigned NOT NULL default '0',
  expire datetime NOT NULL default '0000-00-00 00:00:00'
) TYPE=MyISAM COMMENT='Table to hold account requests ';

--
-- Dumping data for table `requests`
--


--
-- Table structure for table `round`
--

CREATE TABLE round (
  r_uid int(11) NOT NULL auto_increment,
  name text NOT NULL,
  scoring int(11) NOT NULL default '0',
  UNIQUE KEY r_uid (r_uid)
) TYPE=MyISAM COMMENT='Table to hold round types';

--
-- Dumping data for table `round`
--

INSERT INTO round VALUES (1,'Portsmouth',5);
INSERT INTO round VALUES (2,'Albion',2);
INSERT INTO round VALUES (3,'York',2);
INSERT INTO round VALUES (4,'Hereford',2);
INSERT INTO round VALUES (5,'St. George',2);
INSERT INTO round VALUES (6,'Windsor',2);
INSERT INTO round VALUES (7,'Bristol I',2);
INSERT INTO round VALUES (8,'Bristol II',2);
INSERT INTO round VALUES (9,'Bristol III',2);
INSERT INTO round VALUES (10,'Bristol IV',2);
INSERT INTO round VALUES (11,'Bristol V',2);
INSERT INTO round VALUES (12,'Short Windsor',2);
INSERT INTO round VALUES (13,'Junior Windsor',2);
INSERT INTO round VALUES (14,'FITA 18',4);
INSERT INTO round VALUES (15,'FITA 25',4);
INSERT INTO round VALUES (16,'Bray I',5);
INSERT INTO round VALUES (17,'Bray II',5);
INSERT INTO round VALUES (18,'Stafford',5);
INSERT INTO round VALUES (19,'Vegas',3);
INSERT INTO round VALUES (20,'Combined FITA',4);
INSERT INTO round VALUES (21,'New Western',2);
INSERT INTO round VALUES (22,'Long Western',2);
INSERT INTO round VALUES (23,'Western',2);
INSERT INTO round VALUES (24,'Short Western',2);
INSERT INTO round VALUES (25,'Junior Western',2);
INSERT INTO round VALUES (26,'Short Junior Western',2);
INSERT INTO round VALUES (27,'American',2);
INSERT INTO round VALUES (28,'St. Nicholas',2);
INSERT INTO round VALUES (29,'New National',2);
INSERT INTO round VALUES (30,'Long National',2);
INSERT INTO round VALUES (31,'National',2);
INSERT INTO round VALUES (32,'Short National',2);
INSERT INTO round VALUES (33,'Junior National',2);
INSERT INTO round VALUES (34,'Short Junior National',2);
INSERT INTO round VALUES (35,'New Warwick',2);
INSERT INTO round VALUES (36,'Long Warwick',2);
INSERT INTO round VALUES (37,'Warwick',2);
INSERT INTO round VALUES (38,'Short Warwick',2);
INSERT INTO round VALUES (39,'Junior Warwick',2);
INSERT INTO round VALUES (40,'Short Junior Warwick',2);

--
-- Table structure for table `round_dists`
--

CREATE TABLE round_dists (
  round int(11) NOT NULL default '0',
  distance int(11) NOT NULL default '0',
  ends int(11) NOT NULL default '0',
  face int(11) NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table `round_dists`
--

INSERT INTO round_dists VALUES (2,13,6,1);
INSERT INTO round_dists VALUES (1,1,10,1);
INSERT INTO round_dists VALUES (2,7,6,1);
INSERT INTO round_dists VALUES (2,8,6,1);
INSERT INTO round_dists VALUES (3,7,4,1);
INSERT INTO round_dists VALUES (3,8,8,1);
INSERT INTO round_dists VALUES (3,9,12,1);
INSERT INTO round_dists VALUES (4,13,4,1);
INSERT INTO round_dists VALUES (4,7,8,1);
INSERT INTO round_dists VALUES (4,8,12,1);
INSERT INTO round_dists VALUES (5,9,6,1);
INSERT INTO round_dists VALUES (5,8,6,1);
INSERT INTO round_dists VALUES (5,7,6,1);
INSERT INTO round_dists VALUES (6,3,6,1);
INSERT INTO round_dists VALUES (6,13,6,1);
INSERT INTO round_dists VALUES (6,7,6,1);
INSERT INTO round_dists VALUES (7,8,12,1);
INSERT INTO round_dists VALUES (7,7,8,1);
INSERT INTO round_dists VALUES (7,13,4,1);
INSERT INTO round_dists VALUES (8,7,12,1);
INSERT INTO round_dists VALUES (8,13,8,1);
INSERT INTO round_dists VALUES (8,3,4,1);
INSERT INTO round_dists VALUES (9,13,12,1);
INSERT INTO round_dists VALUES (9,3,8,1);
INSERT INTO round_dists VALUES (9,2,4,1);
INSERT INTO round_dists VALUES (10,3,12,1);
INSERT INTO round_dists VALUES (10,2,8,1);
INSERT INTO round_dists VALUES (10,1,4,1);
INSERT INTO round_dists VALUES (11,2,12,1);
INSERT INTO round_dists VALUES (11,1,8,1);
INSERT INTO round_dists VALUES (11,14,4,1);
INSERT INTO round_dists VALUES (12,13,6,1);
INSERT INTO round_dists VALUES (12,3,6,1);
INSERT INTO round_dists VALUES (12,2,6,1);
INSERT INTO round_dists VALUES (13,3,6,1);
INSERT INTO round_dists VALUES (13,2,6,1);
INSERT INTO round_dists VALUES (13,1,6,1);
INSERT INTO round_dists VALUES (14,11,10,1);
INSERT INTO round_dists VALUES (15,12,10,1);
INSERT INTO round_dists VALUES (16,1,5,3);
INSERT INTO round_dists VALUES (17,15,5,2);
INSERT INTO round_dists VALUES (18,5,10,5);
INSERT INTO round_dists VALUES (19,11,10,6);
INSERT INTO round_dists VALUES (20,11,10,3);
INSERT INTO round_dists VALUES (20,12,10,2);
INSERT INTO round_dists VALUES (21,9,8,1);
INSERT INTO round_dists VALUES (21,8,8,1);
INSERT INTO round_dists VALUES (22,8,8,1);
INSERT INTO round_dists VALUES (22,7,8,1);
INSERT INTO round_dists VALUES (23,7,8,1);
INSERT INTO round_dists VALUES (23,13,8,1);
INSERT INTO round_dists VALUES (24,13,8,1);
INSERT INTO round_dists VALUES (24,3,8,1);
INSERT INTO round_dists VALUES (25,3,8,1);
INSERT INTO round_dists VALUES (25,2,8,1);
INSERT INTO round_dists VALUES (26,2,8,1);
INSERT INTO round_dists VALUES (26,1,8,1);
INSERT INTO round_dists VALUES (27,7,5,1);
INSERT INTO round_dists VALUES (27,13,5,1);
INSERT INTO round_dists VALUES (27,3,5,1);
INSERT INTO round_dists VALUES (28,2,6,5);
INSERT INTO round_dists VALUES (28,3,8,5);
INSERT INTO round_dists VALUES (29,9,8,1);
INSERT INTO round_dists VALUES (29,8,4,1);
INSERT INTO round_dists VALUES (30,8,8,1);
INSERT INTO round_dists VALUES (30,7,4,1);
INSERT INTO round_dists VALUES (31,7,8,1);
INSERT INTO round_dists VALUES (31,13,4,1);
INSERT INTO round_dists VALUES (32,13,8,1);
INSERT INTO round_dists VALUES (32,3,4,1);
INSERT INTO round_dists VALUES (33,3,8,1);
INSERT INTO round_dists VALUES (33,2,4,1);
INSERT INTO round_dists VALUES (34,2,8,1);
INSERT INTO round_dists VALUES (34,1,4,1);
INSERT INTO round_dists VALUES (35,9,4,1);
INSERT INTO round_dists VALUES (35,8,4,1);
INSERT INTO round_dists VALUES (36,8,4,1);
INSERT INTO round_dists VALUES (36,7,4,1);
INSERT INTO round_dists VALUES (37,7,4,1);
INSERT INTO round_dists VALUES (37,3,4,1);
INSERT INTO round_dists VALUES (38,13,4,1);
INSERT INTO round_dists VALUES (38,3,4,1);
INSERT INTO round_dists VALUES (39,3,4,1);
INSERT INTO round_dists VALUES (39,2,4,1);
INSERT INTO round_dists VALUES (40,2,4,1);
INSERT INTO round_dists VALUES (40,1,4,1);

--
-- Table structure for table `sales`
--

CREATE TABLE sales (
  sale_uid int(10) unsigned NOT NULL auto_increment,
  title tinytext NOT NULL,
  description text NOT NULL,
  date datetime NOT NULL default '0000-00-00 00:00:00',
  seller int(10) NOT NULL default '0',
  price tinytext NOT NULL,
  direction tinytext NOT NULL,
  UNIQUE KEY sale_uid (sale_uid)
) TYPE=MyISAM COMMENT='Items for sale';

--
-- Dumping data for table `sales`
--

--
-- Table structure for table `scoring`
--

CREATE TABLE scoring (
  ss_uid int(11) NOT NULL auto_increment,
  name text NOT NULL,
  values text NOT NULL,
  UNIQUE KEY ss_uid (ss_uid)
) TYPE=MyISAM COMMENT='Table to hold valid scores for each scoring system';

--
-- Dumping data for table `scoring`
--

INSERT INTO scoring VALUES (1,'GNAS Outdoor Metric (x,10-1))','x,10,9,8,7,6,5,4,3,2,1,m');
INSERT INTO scoring VALUES (2,'GNAS Outdoor Imperial (9-1)','9,7,5,3,1,m');
INSERT INTO scoring VALUES (3,'Tripple Spot (10-6)','10,9,8,7,6,m');
INSERT INTO scoring VALUES (4,'FITA Indoor (10-1)','10,9,8,7,6,5,4,3,2,1,m');
INSERT INTO scoring VALUES (5,'GNAS Indoor (10-1)','10,9,8,7,6,5,4,3,2,1,m');
INSERT INTO scoring VALUES (6,'FITA Outdoor (x,10-1)','x,10,9,8,7,6,5,4,3,2,1,m');

--
-- Table structure for table `session`
--

CREATE TABLE session (
  s_uid int(11) NOT NULL auto_increment,
  user int(11) NOT NULL default '0',
  equipment int(11) NOT NULL default '0',
  shoot int(11) NOT NULL default '0',
  score int(11) NOT NULL default '0',
  UNIQUE KEY s_uid (s_uid)
) TYPE=MyISAM COMMENT='Table of individual session scores';

--
-- Dumping data for table `session`
--

--
-- Table structure for table `shoot`
--

CREATE TABLE shoot (
  sh_uid int(11) NOT NULL auto_increment,
  date date NOT NULL default '0000-00-00',
  round int(11) NOT NULL default '0',
  location text NOT NULL,
  UNIQUE KEY sh_uid (sh_uid)
) TYPE=MyISAM COMMENT='Table of shoot definitions';

--
-- Dumping data for table `shoot`
--

--
-- Table structure for table `user`
--

CREATE TABLE user (
  u_uid int(10) unsigned NOT NULL auto_increment,
  u_name text NOT NULL,
  password text NOT NULL,
  f_name text NOT NULL,
  s_name text NOT NULL,
  email tinytext NOT NULL,
  privilege_level tinyint(3) unsigned NOT NULL default '0',
  created date NOT NULL default '0000-00-00',
  last_log date NOT NULL default '0000-00-00',
  description text,
  UNIQUE KEY u_uid (u_uid)
) TYPE=MyISAM COMMENT='User Admin Table';

--
-- Dumping data for table `user`
--


